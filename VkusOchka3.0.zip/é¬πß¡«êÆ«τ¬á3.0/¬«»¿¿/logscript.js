let currentLoginRole = 'client';

function checkLoginForm() {
    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;
    const staffIdInput = document.getElementById('staff-id');
    const resultDiv = document.getElementById('result');

    resultDiv.textContent = "";
    resultDiv.className = "";

    // Проверка табельного номера, если выбран вход для сотрудника
    if (currentLoginRole === 'staff' && staffIdInput && staffIdInput.value.trim() === "") {
        resultDiv.textContent = "Ошибка. Введите табельный номер.";
        resultDiv.className = "error";
        return;
    }

    if (login.length < 4) {
        resultDiv.textContent = "Ошибка. Логин или почта слишком короткие.";
        resultDiv.className = "error";
        return;
    }

    if (login.includes(" ")) {
        resultDiv.textContent = "Ошибка. Логин не должен содержать пробелы.";
        resultDiv.className = "error";
        return;
    }

    if (password.length < 8) {
        resultDiv.textContent = "Ошибка. Пароль короткий.";
        resultDiv.className = "error";
        return;
    }

    // Успешный вход и ваша анимация
    resultDiv.textContent = (currentLoginRole === 'client') ? "С возвращением! Приятного аппетита!" : "Вход выполнен! Загрузка смены...";
    resultDiv.className = "success";

    resultDiv.animate([
        { opacity: 0, transform: 'translateY(5px)' },
        { opacity: 1, transform: 'translateY(0)', offset: 0.25 },
        { opacity: 0.35, offset: 0.55 },
        { opacity: 1, offset: 0.85 },
        { opacity: 0.6 }
    ], {
        duration: 2000,
        easing: 'ease-in-out',
        fill: 'forwards'
    });

    setTimeout(function() {
        window.location.href = "https://vkusnoitochka.ru/";
    }, 2000);
}

function switchLoginRole(role) {
    currentLoginRole = role;
    const resultDiv = document.getElementById('result');
    resultDiv.textContent = '';
    resultDiv.className = '';

    if (role === 'client') {
        document.getElementById('btn-client').classList.add('active');
        document.getElementById('btn-staff').classList.remove('active');

        document.getElementById('form-title').textContent = 'Вход для клиента';
        document.getElementById('form-subtitle').textContent = 'Войдите, чтобы управлять заказами и бонусами';
        document.getElementById('login-label').textContent = 'Логин или почта:';
        document.getElementById('login').placeholder = 'Введите логин или email';
        document.getElementById('submit-btn').textContent = 'Войти';

        document.getElementById('staff-id-group').style.display = 'none';
        document.getElementById('client-register-box').style.display = 'block';
        document.getElementById('staff-register-box').style.display = 'none';
    } else {
        document.getElementById('btn-staff').classList.add('active');
        document.getElementById('btn-client').classList.remove('active');

        document.getElementById('form-title').textContent = 'Вход для сотрудника';
        document.getElementById('form-subtitle').textContent = 'Доступ к графику смен и рабочим сервисам';
        document.getElementById('login-label').textContent = 'Рабочий логин или почта:';
        document.getElementById('login').placeholder = 'ivanov@qsrsystem.ru';
        document.getElementById('submit-btn').textContent = 'Войти в кабинет сотрудника';

        document.getElementById('staff-id-group').style.display = 'block';
        document.getElementById('client-register-box').style.display = 'none';
        document.getElementById('staff-register-box').style.display = 'block';
    }
}
