
    function checkForm() {
        const login = document.getElementById('login').value;
        const password = document.getElementById('password').value;
        const email = document.getElementById('email').value;
        const resultDiv = document.getElementById('result');

        resultDiv.textContent = "";
        resultDiv.className = "";

        if (login.length < 4) {
            resultDiv.textContent = "Ошибка. Логин короткий.";
            resultDiv.className = "error";
            return;
        }
        if (login.includes(" ")) {
            resultDiv.textContent = "Ошибка. Логин с пробелами.";
            resultDiv.className = "error";
            return; 
        }
        if (password.length < 8) {
            resultDiv.textContent = "Ошибка. Пароль короткий.";
            resultDiv.className = "error";
            return; 
        }
        if (!email.includes("@gmail.com") && !email.includes("@mail.ru") && !email.includes("@yandex.ru")) {
            resultDiv.textContent = "Ошибка. Почта некорректная.";
            resultDiv.className = "error";
            return; 
        }

        resultDiv.textContent = "Приятного аппетита!";
        resultDiv.className = "success";

        setTimeout(function() {
            window.location.href = "https://vkusnoitochka.ru/";
        }, 2000); 
    }
    
     let currentRole = 'client';

        function switchRole(role) {
            currentRole = role;
            const resultDiv = document.getElementById('result');
            resultDiv.textContent = '';

            if (role === 'client') {
                document.getElementById('btn-client').classList.add('active');
                document.getElementById('btn-staff').classList.remove('active');

                document.getElementById('form-title').textContent = 'Регистрация клиента';
                document.getElementById('form-subtitle').textContent = 'Создайте аккаунт для заказов и бонусов';
                document.getElementById('login-label').textContent = 'Логин:';
                document.getElementById('email-label').textContent = 'Почта:';
                document.getElementById('email').placeholder = 'example@mail.com';
                document.getElementById('submit-btn').textContent = 'Зарегистрироваться';

                document.getElementById('staff-id-group').style.display = 'none';
                document.getElementById('staff-login-box').style.display = 'none';
            } else {
                document.getElementById('btn-staff').classList.add('active');
                document.getElementById('btn-client').classList.remove('active');

                document.getElementById('form-title').textContent = 'Регистрация сотрудника';
                document.getElementById('form-subtitle').textContent = 'Доступ к графику смен и рабочим сервисам';
                document.getElementById('login-label').textContent = 'ФИО или рабочий логин:';
                document.getElementById('email-label').textContent = 'Рабочая почта:';
                document.getElementById('email').placeholder = 'ivanov@qsrsystem.ru';
                document.getElementById('submit-btn').textContent = 'Создать аккаунт сотрудника';

                document.getElementById('staff-id-group').style.display = 'block';
                document.getElementById('staff-login-box').style.display = 'block';
            }
        }

            resultDiv.textContent = "Приятного аппетита!";
    resultDiv.className = "success";

    resultDiv.animate([
        { opacity: 0, transform: 'translateY(5px)' }, 
        { opacity: 1, transform: 'translateY(0)', offset: 0.25 }, 
        { opacity: 0.35, offset: 0.55 }, 
        { opacity: 1, offset: 0.85 },  
        { opacity: 0.6 }              
    ], {
        duration: 2000,
        easing: 'ease-in-out',
        fill: 'forwards'
    });

    setTimeout(function() {
        window.location.href = "https://vkusnoitochka.ru";
    }, 2000);
document.getElementById('client-login-box').style.display = (role === 'client') ? 'block' : 'none';
document.getElementById('staff-login-box').style.display = (role === 'staff') ? 'block' : 'none';