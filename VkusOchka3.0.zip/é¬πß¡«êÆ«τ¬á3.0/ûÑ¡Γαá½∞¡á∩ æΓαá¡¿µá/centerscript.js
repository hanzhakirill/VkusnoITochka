        const track = document.getElementById('slidesTrack');
        const slides = document.querySelectorAll('.slide');
        const dotsContainer = document.getElementById('sliderDots');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const slider = document.getElementById('promoSlider');

        let currentIndex = 0;
        let autoSlideInterval;

        slides.forEach((_, index) => {
            const dot = document.createElement('button');
            dot.classList.add('dot');
            if (index === 0) dot.classList.add('active');
            dot.addEventListener('click', () => goToSlide(index));
            dotsContainer.appendChild(dot);
        });

        const dots = document.querySelectorAll('.dot');

        function updateSlider() {
            track.style.transform = `translateX(-${currentIndex * 100}%)`;
            dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === currentIndex);
            });
        }

        function goToSlide(index) {
            currentIndex = (index + slides.length) % slides.length;
            updateSlider();
            resetInterval();
        }

        function nextSlide() {
            goToSlide(currentIndex + 1);
        }

        function prevSlide() {
            goToSlide(currentIndex - 1);
        }

        function startInterval() {
            autoSlideInterval = setInterval(nextSlide, 10000);
        }

        function resetInterval() {
            clearInterval(autoSlideInterval);
            startInterval();
        }

        nextBtn.addEventListener('click', nextSlide);
        prevBtn.addEventListener('click', prevSlide);

        slider.addEventListener('mouseenter', () => clearInterval(autoSlideInterval));
        slider.addEventListener('mouseleave', startInterval);

        startInterval();

        document.addEventListener("DOMContentLoaded", () => {
    const cityElement = document.getElementById("user-city");

    fetch("https://ipwho.is")
        .then(response => response.json())
        .then(data => {
            if (data.success && data.city) {
                cityElement.textContent = data.city;
            } else {
                cityElement.textContent = "Калининград"; 
            }
        })
        .catch(() => {
            cityElement.textContent = "Калининград";
        });
});

document.addEventListener("DOMContentLoaded", () => {
    const subscribeForm = document.getElementById("subscribeForm");
    const emailInput = document.getElementById("subscriberEmail");
    const messageBox = document.getElementById("subscribeMessage");

    if (subscribeForm) {
        subscribeForm.addEventListener("submit", (e) => {
            e.preventDefault(); 
            const email = emailInput.value.trim();

            if (email) {
                messageBox.textContent = `Спасибо! Промокоды отправлены на ${email}`;
                emailInput.value = ""; 
            }
        });
    }
});
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('accept-cookies');

    if (localStorage.getItem('cookiesAccepted') === 'true') {
        cookieBanner.classList.add('hidden');
    }

    acceptBtn.addEventListener('click', () => {
        cookieBanner.classList.add('hidden');
        localStorage.setItem('cookiesAccepted', 'true');
    });